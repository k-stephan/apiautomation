package apiqa.util;

public class filenameconstants 
{

	public static final String BASE_PATH="./src/test/resources/";
	public static final String REQ_FILE_NM=BASE_PATH+"BookingInfo";
	public static final String JSON_SCHEMA = BASE_PATH+"jsonschema.txt";

}
