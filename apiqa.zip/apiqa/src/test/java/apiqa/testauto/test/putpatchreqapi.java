package apiqa.testauto.test;

public class putpatchreqapi
{
	
	public void putreq()
	{
		
		
	}

}
